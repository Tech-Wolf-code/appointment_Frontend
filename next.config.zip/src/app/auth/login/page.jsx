import LoginForm from "@/components/auth/LoginForm";

export default function LogoutPage() {
  return(
    <div>
        <LoginForm/>
    </div>
  )
}
