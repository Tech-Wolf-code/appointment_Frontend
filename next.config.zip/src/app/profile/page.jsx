export default function Profile() {
return <h1>User Profile</h1>;
}